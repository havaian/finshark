<script setup lang="ts">
import { useRoute } from 'vue-router';
import { useI18n } from 'vue-i18n';

const { t } = useI18n();
const route = useRoute();

// Where to go after sign-in completes. Set by router.beforeEach when an
// unauthenticated user hits a protected route. Stash it in sessionStorage so
// the /auth/callback page can read it after Google's redirect - query params
// don't survive the round-trip through Google.
const NEXT_STORAGE_KEY = 'finshark.post_login_next';

function onGoogleSignIn() {
  const next = typeof route.query.next === 'string' ? route.query.next : null;
  if (next) {
    sessionStorage.setItem(NEXT_STORAGE_KEY, next);
  } else {
    sessionStorage.removeItem(NEXT_STORAGE_KEY);
  }

  // Full-page navigation (not fetch): the backend sets an HttpOnly state cookie
  // on /api/auth/google that must round-trip through the browser to the
  // callback. VITE_API_BASE_URL already includes the /api prefix.
  window.location.href = `${import.meta.env.VITE_API_BASE_URL}/auth/google`;
}
</script>

<template>
  <main class="auth-page">
    <div class="auth-card">
      <h1>{{ t('login.title') }}</h1>
      <p class="dim" style="margin-bottom: 22px;">
        {{ t('login.title') }} - {{ t('login.google_btn') }}
      </p>

      <button type="button" class="btn btn-primary btn-block" @click="onGoogleSignIn">
        <svg width="18" height="18" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <path fill="#FFFFFF"
            d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844a4.14 4.14 0 0 1-1.796 2.716v2.258h2.908c1.702-1.567 2.684-3.874 2.684-6.615z" />
          <path fill="#FFFFFF"
            d="M9 18c2.43 0 4.467-.806 5.956-2.185l-2.908-2.258c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18z"
            opacity="0.85" />
          <path fill="#FFFFFF"
            d="M3.964 10.706A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.706V4.962H.957A8.997 8.997 0 0 0 0 9c0 1.452.348 2.827.957 4.038l3.007-2.332z"
            opacity="0.7" />
          <path fill="#FFFFFF"
            d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.962L3.964 7.294C4.672 5.166 6.656 3.58 9 3.58z"
            opacity="0.55" />
        </svg>
        {{ t('login.google_btn') }}
      </button>
    </div>
  </main>
</template>